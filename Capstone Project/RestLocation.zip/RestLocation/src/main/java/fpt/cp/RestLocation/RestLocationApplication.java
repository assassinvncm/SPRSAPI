package fpt.cp.RestLocation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestLocationApplication.class, args);
	}

}
