package fpt.cp.RestLocation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
